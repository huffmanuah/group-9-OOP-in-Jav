/*
 * This is the first test design for the project, meant for the first presentation
 * 
 * 
 */
package UserFirstPres;
import java.util.Scanner;
/**
 *
 * @author Gray-1
 */
public class UserFirstPres {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String name;
        String pass;
        String inpUser;
        String inpPass;
        int choiceentry;
        Scanner input = new Scanner(System.in);
        System.out.println("Create new User");
       System.out.println("Enter Username");
            name = input.nextLine();
           System.out.println("Enter password");
           pass = input.nextLine();
           //this part creates a new user and stores the name and password in the 
           //pass and name variables
        do { //This do while starts up the menu, runs intil exit command is given
        System.out.println("Enter one of the following commands");
        
        System.out.println("1 - login");
        System.out.println("2 - exit");
        Scanner scanchoice = new Scanner(System.in);
        
        System.out.println("Enter 1, 2, or 3");
       choiceentry = scanchoice.nextInt();
       
           switch(choiceentry){
               
               case 1: // first case tests entered name and pass against those given on creation
                System.out.println("Enter Username");
                inpUser = input.nextLine();
                System.out.println("Enter Password");
                inpPass = input.nextLine();
                if(inpUser.equals(name)&& inpPass.equals(pass)){
                    System.out.println("Welcome!");
                }
                else {
                    System.out.println("Incorrect Password");
                } 
            break;   
           case 2: // This outputs a final message and exits the program
                System.out.println("Have a good day");
                System.exit(0);
        break;
           default: System.out.println("Choice must be a value between 1 and 2");
           }
    } while (choiceentry != 2);
    }
    }

